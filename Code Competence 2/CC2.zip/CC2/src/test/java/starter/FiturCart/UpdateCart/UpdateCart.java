//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturCart.UpdateCart;

import net.thucydides.core.annotations.Step;

public class UpdateCart {

    @Step("I Set PUT method endpoints")
    public void SetPOSTmethodendpoints(){
        System.out.println("I Set PUT method endpoints");
    }

    @Step("I Navigate to the Body menu")
    public void NavigatetoBodymenu(){
        System.out.println("I Navigate to the Body menu");
    }

    @Step("I Enter PUT destination URL with Id in parameter")
    public void EnterPUTdestinationURLwithId(){
        System.out.println("I Enter PUT destination URL with Id in parameter");
    }

    @Step("I Select \"raw\" option")
    public void Selectraw(){
        System.out.println("I Select \"raw\" option");
    }

    @Step("I Select \"JSON\" from the text format dropdown")
    public void SelectJSON(){
        System.out.println("I Select \"JSON\" from the text format dropdown");
    }

    @Step("I Click send PUT HTTP request button")
    public void ClicksendPOSTHTTPrequestbutton(){
        System.out.println("I Click send PUT HTTP request button");
    }

    @Step("I enter new changes for data cart in body field")
    public void enternewdatacartinbodyfield(){
        System.out.println("I enter new changes for data cart in body field");
    }

    @Step("I Receive PUT valid HTTP response code 200")
    public void ReceivevalidHTTPresponsecode201(){
        System.out.println("I Receive PUT valid HTTP response code 200");
    }

    @Step("I Receive the data changes that had been updated to the system")
    public void Receivethenewdatathathadbeenadded(){
        System.out.println("I Receive the data changes that had been updated to the system");
    }
}
