//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturCart.AddNewCart;

import net.thucydides.core.annotations.Step;

public class AddNewCart {

    @Step("I set Method POST endpoints")
    public void setMethodPOSTendpoints(){
        System.out.println("I set Method POST endpoints");
    }

    @Step("I Navigate to menu Body")
    public void NavigatetomenuBody(){
        System.out.println("I Navigate to menu Body");
    }

    @Step("I Enter POST URL destination")
    public void EnterPOSTURLdestination(){
        System.out.println("I Enter POST URL destination");
    }

    @Step("I Select \"raw\" opt")
    public void Selectrawopt(){
        System.out.println("I Select \"raw\" opt");
    }

    @Step("I Select \"JSON\" opt from the text type dropdown")
    public void SelectJSONoptfromthetexttypedropdown(){
        System.out.println("I Select \"JSON\" opt from the text type dropdown");
    }

    @Step("I enter new data cart in body field")
    public void enternewdatacartinbodyfield(){
        System.out.println("I enter new data cart in body field");
    }

    @Step("I Click Send POST HTTP request button")
    public void ClickSendPOSTHTTPrequestbutton(){
        System.out.println("I Click Send POST HTTP request button");
    }

    @Step("I Receive Valid HTTP response code 201")
    public void ReceiveValidHTTPresponsecode201(){
        System.out.println("I Receive Valid HTTP response code 201");
    }

    @Step("I Receive the new data product that had been added to the system")
    public void Receivethenewdataproductthathadbeenadded(){
        System.out.println("I Receive the new data product that had been added to the system");
    }
}
