//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturCart.SortCartResults;

import net.thucydides.core.annotations.Step;

public class SortCartResults {

    @Step("I Set GET method endpoint")
    public void SetGETmethodendpoint() { System.out.println("I Set GET method endpoint");
    }

    @Step("I enter GET destination URL with key sort and value desc in parameter")
    public void enterGETdestinationURLwithkeysortandvaluedescinparameter() {
        System.out.println("I enter GET destination URL with key sort and value desc in parameter");
    }

    @Step("I Click Send GET HTTP request button")
    public void ClickSendGETHTTPrequestbutton() {
        System.out.println("I Click Send GET HTTP request button");
    }

    @Step("I Receive GET valid HTTP response code 200 OK")
    public void ReceiveGETvalidHTTPresponsecode200OK() {
        System.out.println("I Receive GET valid HTTP response code 200 OK");
    }

}