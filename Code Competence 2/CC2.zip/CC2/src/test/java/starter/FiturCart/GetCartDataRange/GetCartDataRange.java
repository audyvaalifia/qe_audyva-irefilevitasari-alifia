//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturCart.GetCartDataRange;

import net.thucydides.core.annotations.Step;

public class GetCartDataRange {

    @Step("I set GET method Endpoint")
    public void setGETmethodEndpoint() { System.out.println("I set GET method Endpoint");
    }

    @Step("I enter GET destination URL with key startdate and enddate with values in parameter")
    public void enterGETdestinationURLwithkeystartdateandenddatewithvaluesinparameter() {
        System.out.println("I enter GET destination URL with key startdate and enddate with values in parameter");
    }

    @Step("I click Send GET HTTP request Button")
    public void clickSendGETHTTPrequestButton() {
        System.out.println("I click Send GET HTTP request Button");
    }

    @Step("I receive GET valid HTTP Response code 200 OK")
    public void receiveGETvalidHTTPResponsecode200OK() {
        System.out.println("I receive GET valid HTTP Response code 200 OK");
    }

}