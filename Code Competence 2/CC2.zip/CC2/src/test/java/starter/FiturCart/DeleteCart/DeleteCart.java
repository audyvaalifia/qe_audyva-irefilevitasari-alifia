//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturCart.DeleteCart;

import net.thucydides.core.annotations.Step;

public class DeleteCart {

    @Step("I Set DELETE method endpoints")
    public void SetDELETEmethodendpoints() {
        System.out.println("I Set DELETE method endpoints");
    }

    @Step("I Enter DELETE destination URL with Id in parameter")
    public void EnterDELETEdestinationURLwithIdinparameter() {
        System.out.println("I Enter DELETE destination URL with Id in parameter");
    }

    @Step("I Click send DELETE HTTP request button")
    public void ClicksendDELETEHTTPrequestbutton() {
        System.out.println("I Click send DELETE HTTP request button");
    }

    @Step("I Receive DELETE valid HTTP response code 200 OK and show the deleted content")
    public void ReceiveDELETEvalidHTTPresponsecode200OKandshowthedeletedcontent() {
        System.out.println("I Receive DELETE valid HTTP response code 200 OK and show the deleted content");    }

}