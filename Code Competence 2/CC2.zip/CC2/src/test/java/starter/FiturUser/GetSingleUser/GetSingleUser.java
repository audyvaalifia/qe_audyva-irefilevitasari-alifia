//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturUser.GetSingleUser;

import net.thucydides.core.annotations.Step;

public class GetSingleUser {

    @Step("I set GET Method endpoint")
    public void setGETMethodendpoint() { System.out.println("I set GET Method endpoint");
    }

    @Step("I enter GET destination URL with ID in parameter")
    public void enterGETdestinationURLwithIDinparameter() {
        System.out.println("I enter no GET destination URL with ID in parameter");
    }

    @Step("I click Send GET HTTP Request button")
    public void clickSendGETHTTPRequestbutton() {
        System.out.println("I click Send GET HTTP Request button");
    }

    @Step("I receive GET valid HTTP response Code 200 OK")
    public void receiveGETvalidHTTPresponseCode200OK() {
        System.out.println("I receive GET valid HTTP response Code 200 OK");
    }

}