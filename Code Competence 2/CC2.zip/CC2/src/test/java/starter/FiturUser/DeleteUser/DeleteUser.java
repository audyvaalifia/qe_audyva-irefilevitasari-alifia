//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturUser.DeleteUser;

import net.thucydides.core.annotations.Step;

public class DeleteUser {

    @Step("I set DELETE method Endpoints")
    public void setDELETEmethodEndpoints() {
        System.out.println("I set DELETE method Endpoints");
    }

    @Step("I enter DELETE destination URL with Id in Parameter")
    public void enterDELETEdestinationURLwithIdinParameter() {
        System.out.println("I enter DELETE destination URL with Id in Parameter");
    }

    @Step("I click send DELETE HTTP request Button")
    public void clicksendDELETEHTTPrequestButton() {
        System.out.println("I click send DELETE HTTP request Button");
    }

    @Step("I receive DELETE valid HTTP response Code 200 OK and show the deleted content")
    public void receiveDELETEvalidHTTPresponseCode200OKandshowthedeletedcontent() {
        System.out.println("I receive DELETE valid HTTP response Code 200 OK and show the deleted content");    }

}