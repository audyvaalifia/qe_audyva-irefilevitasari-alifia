//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturUser.LimitResultsUser;

import net.thucydides.core.annotations.Step;

public class LimitResultsUser {

    @Step("I set GET Method Endpoint")
    public void setGETMethodEndpoint() { System.out.println("I set GET Method Endpoint");
    }

    @Step("I enter GET destination URL with key limit and value 5 in parameter")
    public void enterGETdestinationURLwithkeylimitandvalue5inparameter() {
        System.out.println("I enter GET destination URL with key limit and value 5 in parameter");
    }

    @Step("I click Send GET HTTP Request Button")
    public void clickSendGETHTTPRequestButton() {
        System.out.println("I click Send GET HTTP Request Button");
    }

    @Step("I receive GET valid HTTP response Code 200 OK and 5 data")
    public void receiveGETvalidHTTPresponseCode200OKand5data() {
        System.out.println("I receive GET valid HTTP response Code 200 OK and 5 data");
    }

}