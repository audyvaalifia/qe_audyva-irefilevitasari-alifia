//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturUser.AddNewUser;

import net.thucydides.core.annotations.Step;

public class AddNewUser {

    @Step("I set method POST Endpoints")
    public void setmethodPOSTEndpoints(){
        System.out.println("I set method POST Endpoints");
    }

    @Step("I navigate to Menu Body")
    public void navigatetoMenuBody(){
        System.out.println("I navigate to Menu Body");
    }

    @Step("I enter POST URL Destination")
    public void enterPOSTURLDestination(){
        System.out.println("I enter POST URL Destination");
    }

    @Step("I select \"raw\" Opt")
    public void selectrawOpt(){
        System.out.println("I select \"raw\" Opt");
    }

    @Step("I select \"JSON\" opt from the text type Dropdown")
    public void selectJSONoptfromthetexttypeDropdown(){
        System.out.println("I select \"JSON\" opt from the text type Dropdown");
    }

    @Step("I enter new data user in body field")
    public void enternewdatauserinbodyfield(){
        System.out.println("I enter new data user in body field");
    }

    @Step("I click Send POST HTTP request Button")
    public void clickSendPOSTHTTPrequestButton(){
        System.out.println("I click Send POST HTTP request Button");
    }

    @Step("I receive Valid HTTP response Code 201")
    public void receiveValidHTTPresponseCode201(){
        System.out.println("I receive Valid HTTP response Code 201");
    }

    @Step("I receive the new data user that had been added to the system")
    public void receivethenewdatauserthathadbeenadded(){
        System.out.println("I receive the new data user that had been added to the system");
    }
}
