//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturUser.GetAllUsers;

import net.thucydides.core.annotations.Step;

public class GetAllUsers {
    @Step("I set GET method Endpoints")
    public void setGETmethodEndpoints(){
    System.out.println("I set GET method Endpoints");
}

    @Step("I enter Destination URL")
    public void enterGETDestinationURL(){
        System.out.println("I enter Destination URL");
    }

    @Step("I click send GET HTTP request Button")
    public void clicksendGETHTTPrequestButton(){
        System.out.println("I click send GET HTTP request Button");
    }

    @Step("I receive valid HTTP response Code 200")
    public void receivevalidHTTPresponseCode200(){
        System.out.println("I receive valid HTTP response Code 200");
    }
    @Step("I receive the list of all users")
    public void receivethelistofallusers(){
        System.out.println("I receive the list of all users");
    }
}
