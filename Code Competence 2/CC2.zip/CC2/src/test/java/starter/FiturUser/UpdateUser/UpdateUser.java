//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturUser.UpdateUser;

import net.thucydides.core.annotations.Step;

public class UpdateUser {

    @Step("I set PUT method Endpoints")
    public void setPOSTmethodEndpoints(){
        System.out.println("I set PUT method Endpoints");
    }

    @Step("I navigate to the Body Menu")
    public void navigatetoBodyMenu(){
        System.out.println("I navigate to the Body Menu");
    }

    @Step("I enter PUT destination URL with ID in parameter")
    public void enterPUTdestinationURLwithID(){
        System.out.println("I enter PUT destination URL with ID in parameter");
    }

    @Step("I select \"raw\" Option")
    public void selectRaw(){
        System.out.println("I select \"raw\" Option");
    }

    @Step("I select \"JSON\" from the text format Dropdown")
    public void selectJSON(){
        System.out.println("I select \"JSON\" from the text format Dropdown");
    }

    @Step("I click send PUT HTTP request Button")
    public void clicksendPOSTHTTPrequestButton(){
        System.out.println("I click send PUT HTTP request Button");
    }

    @Step("I enter new changes for data user in body field")
    public void enternewdatauserinbodyfield(){
        System.out.println("I enter new changes for data user in body field");
    }

    @Step("I receive PUT valid HTTP response Code 200")
    public void receivevalidHTTPresponseCode201(){
        System.out.println("I receive PUT valid HTTP response Code 200");
    }

    @Step("I receive the data changes that had been updated to the System")
    public void receivethenewdatathathadbeenAdded(){
        System.out.println("I receive the data changes that had been updated to the System");
    }
}
