//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturProduct.DeleteProduct;

import net.thucydides.core.annotations.Step;
import org.junit.Assert;

public class DeleteProduct {

    @Step("I set DELETE method endpoints")
    public void setDELETEmethodendpoints() {
        System.out.println("I set DELETE method endpoints");
    }

    @Step("I enter DELETE destination URL with Id in parameter")
    public void enterDELETEdestinationURLwithIdinparameter() {
        System.out.println("I enter DELETE destination URL with Id in parameter");
    }

    @Step("I click send DELETE HTTP request button")
    public void clicksendDELETEHTTPrequestbutton() {
        System.out.println("I click send DELETE HTTP request button");
    }

    @Step("I receive DELETE valid HTTP response code 200 OK and show the deleted content")
    public void receiveDELETEvalidHTTPresponsecode200OKandshowthedeletedcontent() {
        System.out.println("I receive DELETE valid HTTP response code 200 OK and show the deleted content");    }

}