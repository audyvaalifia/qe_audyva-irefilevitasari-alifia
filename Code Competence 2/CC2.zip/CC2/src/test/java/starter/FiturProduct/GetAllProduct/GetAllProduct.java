//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturProduct.GetAllProduct;

import net.thucydides.core.annotations.Step;

public class GetAllProduct {
    @Step("I set GET method endpoints")
    public void setGETmethodendpoints(){
    System.out.println("I set GET method endpoints");
}

    @Step("I enter destination URL")
    public void enterGETdestinationURL(){
        System.out.println("I enter destination URL");
    }

    @Step("I click send GET HTTP request button")
    public void clicksendGETHTTPrequestbutton(){
        System.out.println("I click send GET HTTP request button");
    }

    @Step("I receive valid HTTP response code 200")
    public void receivevalidHTTPresponsecode200(){
        System.out.println("I receive valid HTTP response code 200");
    }
    @Step("I receive the list of all products")
    public void receivethelistofallproducts(){
        System.out.println("I receive the list of all products");
    }
}
