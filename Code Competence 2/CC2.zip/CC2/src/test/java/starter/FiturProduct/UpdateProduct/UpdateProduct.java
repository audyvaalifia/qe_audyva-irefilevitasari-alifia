//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturProduct.UpdateProduct;

import net.thucydides.core.annotations.Step;

public class UpdateProduct {

    @Step("I set PUT method endpoints")
    public void setPOSTmethodendpoints(){
        System.out.println("I set PUT method endpoints");
    }

    @Step("I navigate to the Body menu")
    public void navigatetoBodymenu(){
        System.out.println("I navigate to the Body menu");
    }

    @Step("I enter PUT destination URL with Id in parameter")
    public void enterPUTdestinationURLwithId(){
        System.out.println("I enter PUT destination URL with Id in parameter");
    }

    @Step("I select \"raw\" option")
    public void selectraw(){
        System.out.println("I select \"raw\" option");
    }

    @Step("I select \"JSON\" from the text format dropdown")
    public void selectJSON(){
        System.out.println("I select \"JSON\" from the text format dropdown");
    }

    @Step("I click send PUT HTTP request button")
    public void clicksendPOSTHTTPrequestbutton(){
        System.out.println("I click send PUT HTTP request button");
    }

    @Step("I enter new changes for data product in body field")
    public void enternewdataproductinbodyfield(){
        System.out.println("I enter new changes for data product in body field");
    }

    @Step("I receive PUT valid HTTP response code 200")
    public void receivevalidHTTPresponsecode201(){
        System.out.println("I receive PUT valid HTTP response code 200");
    }

    @Step("I receive the data changes that had been updated to the system")
    public void receivethenewdatathathadbeenadded(){
        System.out.println("I receive the data changes that had been updated to the system");
    }
}
