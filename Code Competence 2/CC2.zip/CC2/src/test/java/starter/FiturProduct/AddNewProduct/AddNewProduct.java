//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturProduct.AddNewProduct;

import net.thucydides.core.annotations.Step;

public class AddNewProduct {

    @Step("I set method POST endpoints")
    public void setmethodPOSTendpoints(){
        System.out.println("I set method POST endpoints");
    }

    @Step("I navigate to menu Body")
    public void navigatetomenuBody(){
        System.out.println("I navigate to menu Body");
    }

    @Step("I enter POST URL destination")
    public void enterPOSTURLdestination(){
        System.out.println("I enter POST URL destination");
    }

    @Step("I select \"raw\" opt")
    public void selectrawopt(){
        System.out.println("I select \"raw\" opt");
    }

    @Step("I select \"JSON\" opt from the text type dropdown")
    public void selectJSONoptfromthetexttypedropdown(){
        System.out.println("I select \"JSON\" opt from the text type dropdown");
    }

    @Step("I enter new data product in body field")
    public void enternewdataproductinbodyfield(){
        System.out.println("I enter new data product in body field");
    }

    @Step("I click Send POST HTTP request button")
    public void clickSendPOSTHTTPrequestbutton(){
        System.out.println("I click Send POST HTTP request button");
    }

    @Step("I receive Valid HTTP response code 201")
    public void receiveValidHTTPresponsecode201(){
        System.out.println("I receive Valid HTTP response code 201");
    }

    @Step("I receive the new data product that had been added to the system")
    public void receivethenewdataproductthathadbeenadded(){
        System.out.println("I receive the new data product that had been added to the system");
    }
}
