//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.FiturLogin.LoginNegative;

import net.thucydides.core.annotations.Step;
import org.junit.Assert;

public class LoginNegative {

    @Step("I set POST method endpoint")
    public void setPOSTmethodendpoint(){
        System.out.println("I set POST method endpoint");
    }

    @Step("I navigate to menu named Body")
    public void navigatetomenunamedBody(){
        System.out.println("I navigate to menu named Body");
    }

    @Step("I enter destination POST URL")
    public void enterdestinationPOSTURL(){
        System.out.println("I enter destination POST URL");
    }

    @Step("I select option named \"raw\"")
    public void selectoptionnamedraw(){
        System.out.println("I select option named \"raw\"");
    }

    @Step("I select \"JSON\" format from dropdown")
    public void selectJSONformatfromdropdown(){
        System.out.println("I select \"JSON\" format from dropdown");
    }

    @Step("I enter an Invalid username and valid password in body field")
    public void enteranInvalidusernameandvalidpasswordinbodyfield(){
        System.out.println("I enter an Invalid username and valid password in body field");
    }

    @Step("I click send POST HTTP button")
    public void clicksendPOSTHTTPbutton(){
        System.out.println("I click send POST HTTP button");
    }

    @Step("I receive POST valid HTTP response code 401 Unauthorized username or password is incorrect")
    public void receivePOSTvalidHTTPresponsecode401Unauthorized(){System.out.println("I receive POST valid HTTP response code 401 Unauthorized username or password is incorrect");   }
}
