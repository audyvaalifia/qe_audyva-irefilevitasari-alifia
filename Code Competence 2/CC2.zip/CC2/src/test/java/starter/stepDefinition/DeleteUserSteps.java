package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturUser.DeleteUser.DeleteUser;

public class DeleteUserSteps {
    @Steps
    DeleteUser DeleteUser;

    @Given("I set DELETE method Endpoints")
    public void setDELETEmethodEndpoints(){
        DeleteUser.setDELETEmethodEndpoints();
    }
    @When("I enter DELETE destination URL with Id in Parameter")
    public void enterDELETEdestinationURLwithIdinParameter(){
        DeleteUser.enterDELETEdestinationURLwithIdinParameter();
    }
    @And("I click send DELETE HTTP request Button")
    public void clicksendDELETEHTTPrequestButton(){
        DeleteUser.clicksendDELETEHTTPrequestButton();
    }

    @Then("I receive DELETE valid HTTP response Code 200 OK and show the deleted content")
    public void receiveDELETEvalidHTTPresponseCode200OKandshowthedeletedcontent(){
        DeleteUser.receiveDELETEvalidHTTPresponseCode200OKandshowthedeletedcontent();
    }
}
