package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturUser.UpdateUser.UpdateUser;

public class UpdateUserSteps {
    @Steps
    UpdateUser UpdateUser;

    @Given("I set PUT method Endpoints")
    public void setPOSTmethodEndpoints(){
        UpdateUser.setPOSTmethodEndpoints();
    }
    @When("I navigate to the Body Menu")
    public void navigatetoBodymenu(){
        UpdateUser.navigatetoBodyMenu();
    }
    @And("I enter PUT destination URL with ID in parameter")
    public void enterPUTdestinationURLwithID(){
        UpdateUser.enterPUTdestinationURLwithID();
    }
    @And("I select \"raw\" Option")
    public void selectRaw(){
        UpdateUser.selectRaw();
    }
    @And("I select \"JSON\" from the text format Dropdown")
    public void selectJSON(){
        UpdateUser.selectJSON();
    }
    @And("I enter new changes for data user in body field")
    public void enternewdatauserinbodyfield(){
        UpdateUser.enternewdatauserinbodyfield();
    }
    @And("I click send PUT HTTP request Button")
    public void clicksendPOSTHTTPrequestButton(){
        UpdateUser.clicksendPOSTHTTPrequestButton();
    }
    @Then("I receive PUT valid HTTP response Code 200")
    public void receivevalidHTTPresponseCode201(){
        UpdateUser.receivevalidHTTPresponseCode201();
    }
    @And("I receive the data changes that had been updated to the System")
    public void receivethenewdatathathadbeenAdded(){
        UpdateUser.receivethenewdatathathadbeenAdded();
    }
}
