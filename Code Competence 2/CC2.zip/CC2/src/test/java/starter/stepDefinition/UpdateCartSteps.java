package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturCart.UpdateCart.UpdateCart;

public class UpdateCartSteps {
    @Steps
    UpdateCart UpdateCart;

    @Given("I Set PUT method endpoints")
    public void SetPOSTmethodendpoints(){
        UpdateCart.SetPOSTmethodendpoints();
    }
    @When("I Navigate to the Body menu")
    public void NavigatetoBodymenu(){
        UpdateCart.NavigatetoBodymenu();
    }
    @And("I Enter PUT destination URL with Id in parameter")
    public void EnterPUTdestinationURLwithId(){
        UpdateCart.EnterPUTdestinationURLwithId();
    }
    @And("I Select \"raw\" option")
    public void Selectraw(){
        UpdateCart.Selectraw();
    }
    @And("I Select \"JSON\" from the text format dropdown")
    public void SelectJSON(){
        UpdateCart.SelectJSON();
    }
    @And("I enter new changes for data cart in body field")
    public void enternewdatacartinbodyfield(){
        UpdateCart.enternewdatacartinbodyfield();
    }
    @And("I Click send PUT HTTP request button")
    public void ClicksendPOSTHTTPrequestbutton(){
        UpdateCart.ClicksendPOSTHTTPrequestbutton();
    }
    @Then("I Receive PUT valid HTTP response code 200")
    public void ReceivevalidHTTPresponsecode201(){
        UpdateCart.ReceivevalidHTTPresponsecode201();
    }
    @And("I Receive the data changes that had been updated to the system")
    public void Receivethenewdatathathadbeenadded(){
        UpdateCart.Receivethenewdatathathadbeenadded();
    }
}
