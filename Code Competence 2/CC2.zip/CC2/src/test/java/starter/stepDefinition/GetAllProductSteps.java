package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturProduct.GetAllProduct.GetAllProduct;

public class GetAllProductSteps {
    @Steps
    GetAllProduct GetAllProduct;
    @Given("I set GET method endpoints")
    public void setGETmethodendpoints(){
        GetAllProduct.setGETmethodendpoints();
    }
    @When("I enter destination URL")
    public void enterGETdestinationURL(){
        GetAllProduct.enterGETdestinationURL();
    }
    @And("I click send GET HTTP request button")
    public void clicksendGETHTTPrequestbutton(){
        GetAllProduct.clicksendGETHTTPrequestbutton();
    }
    @Then("I receive valid HTTP response code 200")
    public void receivevalidHTTPresponsecode200(){
        GetAllProduct.receivevalidHTTPresponsecode200();
    }
    @And("I receive the list of all products")
    public void receivethelistofallproducts(){
        GetAllProduct.receivethelistofallproducts();
    }
}
