package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturUser.AddNewUser.AddNewUser;

public class AddNewUserSteps {
    @Steps
    AddNewUser AddNewUser;

    @Given("I set method POST Endpoints")
    public void setmethodPOSTEndpoints(){
        AddNewUser.setmethodPOSTEndpoints();
    }
    @When("I navigate to Menu Body")
    public void navigatetoMenuBody(){
        AddNewUser.navigatetoMenuBody();
    }
    @And("I enter POST URL Destination")
    public void enterPOSTURLDestination(){
        AddNewUser.enterPOSTURLDestination();
    }
    @And("I select \"raw\" Opt")
    public void selectrawOpt(){
        AddNewUser.selectrawOpt();
    }
    @And("I select \"JSON\" opt from the text type Dropdown")
    public void selectJSONoptfromthetexttypeDropdown(){
        AddNewUser.selectJSONoptfromthetexttypeDropdown();
    }
    @And("I enter new data user in body field")
    public void enternewdatauserinbodyfield(){
        AddNewUser.enternewdatauserinbodyfield();
    }
    @And("I click Send POST HTTP request Button")
    public void clickSendPOSTHTTPrequestButton(){
        AddNewUser.clickSendPOSTHTTPrequestButton();
    }
    @Then("I receive Valid HTTP response Code 201")
    public void receiveValidHTTPresponseCode201(){
        AddNewUser.receiveValidHTTPresponseCode201();
    }
    @And("I receive the new data user that had been added to the system")
    public void receivethenewdatauserthathadbeenadded(){
        AddNewUser.receivethenewdatauserthathadbeenadded();
    }
}
