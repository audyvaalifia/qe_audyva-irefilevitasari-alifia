package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturProduct.GetSingleProduct.GetSingleProduct;

public class GetSingleProductSteps {
    @Steps
    GetSingleProduct GetSingleProduct;

    @Given("I set GET method endpoint")
    public void setGETmethodendpoint(){
        GetSingleProduct.setGETmethodendpoint();
    }
    @When("I enter GET destination URL with Id in parameter")
    public void enterGETdestinationURLwithIdinparameter(){
        GetSingleProduct.enterGETdestinationURLwithIdinparameter();
    }
    @And("I click Send GET HTTP request button")
    public void clickSendGETHTTPrequestbutton(){
        GetSingleProduct.clickSendGETHTTPrequestbutton();
    }
    @Then("I receive GET valid HTTP response code 200 OK")
    public void receiveGETvalidHTTPresponsecode200OK(){
        GetSingleProduct.receiveGETvalidHTTPresponsecode200OK();
    }
}
