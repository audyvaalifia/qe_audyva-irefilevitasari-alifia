package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturProduct.UpdateProduct.UpdateProduct;

public class UpdateProductSteps {
    @Steps
    UpdateProduct UpdateProduct;

    @Given("I set PUT method endpoints")
    public void setPOSTmethodendpoints(){
        UpdateProduct.setPOSTmethodendpoints();
    }
    @When("I navigate to the Body menu")
    public void navigatetoBodymenu(){
        UpdateProduct.navigatetoBodymenu();
    }
    @And("I enter PUT destination URL with Id in parameter")
    public void enterPUTdestinationURLwithId(){
        UpdateProduct.enterPUTdestinationURLwithId();
    }
    @And("I select \"raw\" option")
    public void selectraw(){
        UpdateProduct.selectraw();
    }
    @And("I select \"JSON\" from the text format dropdown")
    public void selectJSON(){
        UpdateProduct.selectJSON();
    }
    @And("I enter new changes for data product in body field")
    public void enternewdataproductinbodyfield(){
        UpdateProduct.enternewdataproductinbodyfield();
    }
    @And("I click send PUT HTTP request button")
    public void clicksendPOSTHTTPrequestbutton(){
        UpdateProduct.clicksendPOSTHTTPrequestbutton();
    }
    @Then("I receive PUT valid HTTP response code 200")
    public void receivevalidHTTPresponsecode201(){
        UpdateProduct.receivevalidHTTPresponsecode201();
    }
    @And("I receive the data changes that had been updated to the system")
    public void receivethenewdatathathadbeenadded(){
        UpdateProduct.receivethenewdatathathadbeenadded();
    }
}
