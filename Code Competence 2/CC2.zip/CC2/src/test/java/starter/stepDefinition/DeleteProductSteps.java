package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturProduct.DeleteProduct.DeleteProduct;

public class DeleteProductSteps {
    @Steps
    DeleteProduct DeleteProduct;

    @Given("I set DELETE method endpoints")
    public void setDELETEmethodendpoints(){
        DeleteProduct.setDELETEmethodendpoints();
    }
    @When("I enter DELETE destination URL with Id in parameter")
    public void enterDELETEdestinationURLwithIdinparameter(){
        DeleteProduct.enterDELETEdestinationURLwithIdinparameter();
    }
    @And("I click send DELETE HTTP request button")
    public void clicksendDELETEHTTPrequestbutton(){
        DeleteProduct.clicksendDELETEHTTPrequestbutton();
    }

    @Then("I receive DELETE valid HTTP response code 200 OK and show the deleted content")
    public void receiveDELETEvalidHTTPresponsecode200OKandshowthedeletedcontent(){
        DeleteProduct.receiveDELETEvalidHTTPresponsecode200OKandshowthedeletedcontent();
    }
}
