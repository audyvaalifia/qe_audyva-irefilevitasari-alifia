package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturCart.GetCartDataRange.GetCartDataRange;

public class GetCartDataRangeSteps {
    @Steps
    GetCartDataRange GetCartDataRange;

    @Given("I set GET method Endpoint")
    public void setGETmethodendpoint(){
        GetCartDataRange.setGETmethodEndpoint();
    }
    @When("I enter GET destination URL with key startdate and enddate with values in parameter")
    public void enterGETdestinationURLwithkeystartdateandenddatewithvaluesinparameter(){
        GetCartDataRange.enterGETdestinationURLwithkeystartdateandenddatewithvaluesinparameter();
    }
    @And("I click Send GET HTTP request Button")
    public void clickSendGETHTTPrequestButton(){
        GetCartDataRange.clickSendGETHTTPrequestButton();
    }
    @Then("I receive GET valid HTTP Response code 200 OK")
    public void receiveGETvalidHTTPResponsecode200OK(){
        GetCartDataRange.receiveGETvalidHTTPResponsecode200OK();
    }
}
