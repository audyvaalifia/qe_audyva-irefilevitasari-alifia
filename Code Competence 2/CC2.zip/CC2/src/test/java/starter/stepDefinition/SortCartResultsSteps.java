package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturCart.SortCartResults.SortCartResults;

public class SortCartResultsSteps {
    @Steps
    SortCartResults SortCartResults;

    @Given("I Set GET method endpoint")
    public void SetGETmethodendpoint(){
        SortCartResults.SetGETmethodendpoint();
    }
    @When("I enter GET destination URL with key sort and value desc in parameter")
    public void enterGETdestinationURLwithkeysortandvaluedescinparameter(){
        SortCartResults.enterGETdestinationURLwithkeysortandvaluedescinparameter();
    }
    @And("I Click Send GET HTTP request button")
    public void ClickSendGETHTTPrequestbutton(){
        SortCartResults.ClickSendGETHTTPrequestbutton();
    }
    @Then("I Receive GET valid HTTP response code 200 OK")
    public void ReceiveGETvalidHTTPresponsecode200OK(){
        SortCartResults.ReceiveGETvalidHTTPresponsecode200OK();
    }
}
