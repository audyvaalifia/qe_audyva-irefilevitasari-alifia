package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturUser.LimitResultsUser.LimitResultsUser;

public class LimitResultsUserSteps {
    @Steps
    LimitResultsUser LimitResultsUser;

    @Given("I set GET Method Endpoint")
    public void setGETMethodEndpoint(){
        LimitResultsUser.setGETMethodEndpoint();
    }
    @When("I enter GET destination URL with key limit and value 5 in parameter")
    public void enterGETdestinationURLwithkeylimitandvalue5inparameter(){
        LimitResultsUser.enterGETdestinationURLwithkeylimitandvalue5inparameter();
    }
    @And("I click Send GET HTTP Request Button")
    public void clickSendGETHTTPRequestButton(){
        LimitResultsUser.clickSendGETHTTPRequestButton();
    }
    @Then("I receive GET valid HTTP response Code 200 OK and 5 data")
    public void receiveGETvalidHTTPresponseCode200OKand5data(){
        LimitResultsUser.receiveGETvalidHTTPresponseCode200OKand5data();
    }
}
