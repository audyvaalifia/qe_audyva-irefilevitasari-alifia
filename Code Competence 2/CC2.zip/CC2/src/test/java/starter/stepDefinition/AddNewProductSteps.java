package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturProduct.AddNewProduct.AddNewProduct;

public class AddNewProductSteps {
    @Steps
    AddNewProduct AddNewProduct;

    @Given("I set method POST endpoints")
    public void setmethodPOSTendpoints(){
        AddNewProduct.setmethodPOSTendpoints();
    }
    @When("I navigate to menu Body")
    public void navigatetomenuBody(){
        AddNewProduct.navigatetomenuBody();
    }
    @And("I enter POST URL destination")
    public void enterPOSTURLdestination(){
        AddNewProduct.enterPOSTURLdestination();
    }
    @And("I select \"raw\" opt")
    public void selectrawopt(){
        AddNewProduct.selectrawopt();
    }
    @And("I select \"JSON\" opt from the text type dropdown")
    public void selectJSONoptfromthetexttypedropdown(){
        AddNewProduct.selectJSONoptfromthetexttypedropdown();
    }
    @And("I enter new data product in body field")
    public void enternewdataproductinbodyfield(){
        AddNewProduct.enternewdataproductinbodyfield();
    }
    @And("I click Send POST HTTP request button")
    public void clickSendPOSTHTTPrequestbutton(){
        AddNewProduct.clickSendPOSTHTTPrequestbutton();
    }
    @Then("I receive Valid HTTP response code 201")
    public void receiveValidHTTPresponsecode201(){
        AddNewProduct.receiveValidHTTPresponsecode201();
    }
    @And("I receive the new data product that had been added to the system")
    public void receivethenewdataproductthathadbeenadded(){
        AddNewProduct.receivethenewdataproductthathadbeenadded();
    }
}
