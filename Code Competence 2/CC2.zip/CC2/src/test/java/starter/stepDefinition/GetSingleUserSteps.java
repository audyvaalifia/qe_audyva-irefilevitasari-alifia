package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturUser.GetSingleUser.GetSingleUser;

public class GetSingleUserSteps {
    @Steps
    GetSingleUser GetSingleUser;

    @Given("I set GET Method endpoint")
    public void setGETMethodendpoint(){
        GetSingleUser.setGETMethodendpoint();
    }
    @When("I enter GET destination URL with ID in parameter")
    public void enterGETdestinationURLwithIDinparameter(){
        GetSingleUser.enterGETdestinationURLwithIDinparameter();
    }
    @And("I click Send GET HTTP Request button")
    public void clickSendGETHTTPRequestbutton(){
        GetSingleUser.clickSendGETHTTPRequestbutton();
    }
    @Then("I receive GET valid HTTP response Code 200 OK")
    public void receiveGETvalidHTTPresponseCode200OK(){
        GetSingleUser.receiveGETvalidHTTPresponseCode200OK();
    }
}
