package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturUser.GetAllUsers.GetAllUsers;

public class GetAllUsersSteps {
    @Steps
    GetAllUsers GetAllUsers;
    @Given("I set GET method Endpoints")
    public void setGETmethodEndpoints(){
        GetAllUsers.setGETmethodEndpoints();
    }
    @When("I enter Destination URL")
    public void enterGETDestinationURL(){
        GetAllUsers.enterGETDestinationURL();
    }
    @And("I click send GET HTTP request Button")
    public void clicksendGETHTTPrequestButton(){
        GetAllUsers.clicksendGETHTTPrequestButton();
    }
    @Then("I receive valid HTTP response Code 200")
    public void receivevalidHTTPresponseCode200(){
        GetAllUsers.receivevalidHTTPresponseCode200();
    }
    @And("I receive the list of all users")
    public void receivethelistofallusers(){
        GetAllUsers.receivethelistofallusers();
    }
}
