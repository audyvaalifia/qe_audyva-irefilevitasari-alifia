package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturCart.AddNewCart.AddNewCart;

public class AddNewCartSteps {
    @Steps
    AddNewCart AddNewCart;

    @Given("I set Method POST endpoints")
    public void setMethodPOSTendpoints(){
        AddNewCart.setMethodPOSTendpoints();
    }
    @When("I Navigate to menu Body")
    public void NavigatetomenuBody(){
        AddNewCart.NavigatetomenuBody();
    }
    @And("I Enter POST URL destination")
    public void EnterPOSTURLdestination(){
        AddNewCart.EnterPOSTURLdestination();
    }
    @And("I Select \"raw\" opt")
    public void Selectrawopt(){
        AddNewCart.Selectrawopt();
    }
    @And("I Select \"JSON\" opt from the text type dropdown")
    public void SelectJSONoptfromthetexttypedropdown(){
        AddNewCart.SelectJSONoptfromthetexttypedropdown();
    }
    @And("I enter new data cart in body field")
    public void enternewdatacartinbodyfield(){
        AddNewCart.enternewdatacartinbodyfield();
    }
    @And("I Click Send POST HTTP request button")
    public void ClickSendPOSTHTTPrequestbutton(){
        AddNewCart.ClickSendPOSTHTTPrequestbutton();
    }
    @Then("I Receive Valid HTTP response code 201")
    public void ReceiveValidHTTPresponsecode201(){
        AddNewCart.ReceiveValidHTTPresponsecode201();
    }
    @And("I Receive the new data product that had been added to the system")
    public void Receivethenewdataproductthathadbeenadded(){
        AddNewCart.Receivethenewdataproductthathadbeenadded();
    }
}
