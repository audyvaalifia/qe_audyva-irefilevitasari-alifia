package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturLogin.LoginPositive.LoginPositive;

public class LoginPositiveSteps {
    @Steps
    LoginPositive LoginPositive;

    @Given("I set POST method endpoints")
    public void setPOSTmethodendpoints(){
        LoginPositive.setPOSTmethodendpoints();
    }
    @When("I navigate to Body menu")
    public void navigatetoBodymenu(){
        LoginPositive.navigatetoBodymenu();
    }
    @And("I enter POST destination URL")
    public void enterPOSTdestinationURL(){
        LoginPositive.enterPOSTdestinationURL();
    }
    @And("I select \"raw\"")
    public void selectraw(){
        LoginPositive.selectraw();
    }
    @And("I select \"JSON\" from the text type dropdown")
    public void selectJSON(){
        LoginPositive.selectJSON();
    }
    @And("I enter username and password in body field")
    public void enterusernameandpasswordinbodyfield(){
        LoginPositive.enterusernameandpasswordinbodyfield();
    }
    @And("I click send POST HTTP request button")
    public void clicksendPOSTHTTPrequestbutton(){
        LoginPositive.clicksendPOSTHTTPrequestbutton();
    }
    @Then("I receive valid HTTP response code 201")
    public void receivevalidHTTPresponsecode201(){
        LoginPositive.receivevalidHTTPresponsecode201();
    }
    @And("I receive the new data that had been added to the system")
    public void receivethenewdatathathadbeenadded(){
        LoginPositive.receivethenewdatathathadbeenadded();
    }
}
