package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturLogin.LoginNegative.LoginNegative;

public class LoginNegativeSteps {
    @Steps
    LoginNegative LoginNegative;

    @Given("I set POST method endpoint")
    public void setPOSTmethodendpoint(){
        LoginNegative.setPOSTmethodendpoint();
    }
    @When("I navigate to menu named Body")
    public void navigatetomenunamedBody(){
        LoginNegative.navigatetomenunamedBody();
    }
    @And("I enter destination POST URL")
    public void enterdestinationPOSTURL(){
        LoginNegative.enterdestinationPOSTURL();
    }

    @And("I select option named \"raw\"")
    public void selectoptionnamedraw(){
        LoginNegative.selectoptionnamedraw();
    }
    @And("I select \"JSON\" format from dropdown")
    public void selectJSONformatfromdropdown(){
        LoginNegative.selectJSONformatfromdropdown();
    }
    @And("I enter an Invalid username and valid password in body field")
    public void enteranInvalidusernameandvalidpasswordinbodyfield(){
        LoginNegative.enteranInvalidusernameandvalidpasswordinbodyfield();
    }
    @And("I click send POST HTTP button")
    public void clicksendPOSTHTTPbutton(){
        LoginNegative.clicksendPOSTHTTPbutton();
    }
    @Then("I receive POST valid HTTP response code 401 Unauthorized username or password is incorrect")
    public void receivePOSTvalidHTTPresponsecode401Unauthorized(){
        LoginNegative.receivePOSTvalidHTTPresponsecode401Unauthorized();
    }
}
