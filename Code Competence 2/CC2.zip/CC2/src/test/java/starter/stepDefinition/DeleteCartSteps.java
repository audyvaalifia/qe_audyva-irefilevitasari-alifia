package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.FiturCart.DeleteCart.DeleteCart;

public class DeleteCartSteps {
    @Steps
    DeleteCart DeleteCart;

    @Given("I Set DELETE method endpoints")
    public void SetDELETEmethodendpoints(){
        DeleteCart.SetDELETEmethodendpoints();
    }
    @When("I Enter DELETE destination URL with Id in parameter")
    public void EnterDELETEdestinationURLwithIdinparameter(){
        DeleteCart.EnterDELETEdestinationURLwithIdinparameter();
    }
    @And("I Click send DELETE HTTP request button")
    public void ClicksendDELETEHTTPrequestbutton(){
        DeleteCart.ClicksendDELETEHTTPrequestbutton();
    }

    @Then("I Receive DELETE valid HTTP response code 200 OK and show the deleted content")
    public void ReceiveDELETEvalidHTTPresponsecode200OKandshowthedeletedcontent(){
        DeleteCart.ReceiveDELETEvalidHTTPresponsecode200OKandshowthedeletedcontent();
    }
}
