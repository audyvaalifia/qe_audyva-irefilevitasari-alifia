package starter.stepDefinitionNeg;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.ViewUserByIdNeg.ViewUserByIdNeg;

public class ViewUserByIdStepsNeg {
    @Steps
    ViewUserByIdNeg ViewUserByIdNeg;

    @Given("I set method endpoints GET")
    public void setmethodendpointsGET(){
        ViewUserByIdNeg.setmethodendpointsGET();
    }
    @When("I enter Invalid GET destination URL with Id in parameter")
    public void enterInvalidGETdestinationURLwithIdinparameter(){
        ViewUserByIdNeg.enterInvalidGETdestinationURLwithIdinparameter();
    }
    @And("I click Send GET HTTP button")
    public void clickSendGETHTTPbutton(){
        ViewUserByIdNeg.clickSendGETHTTPbutton();
    }
    @Then("I receive valid HTTP response code 404 Not Found")
    public void receivevalidHTTPresponsecode404NotFound(){
        ViewUserByIdNeg.receivevalidHTTPresponsecode404NotFound();
    }
}
