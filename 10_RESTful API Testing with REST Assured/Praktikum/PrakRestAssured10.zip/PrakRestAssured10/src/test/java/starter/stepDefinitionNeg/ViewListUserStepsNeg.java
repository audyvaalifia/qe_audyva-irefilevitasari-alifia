package starter.stepDefinitionNeg;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.ViewListUserNeg.ViewListUserNeg;

public class ViewListUserStepsNeg {
    @Steps
    ViewListUserNeg ViewListUserNeg;
    @Given("I set method endpoint GET")
    public void setmethodendpointGET(){
        ViewListUserNeg.setmethodendpointGET();
    }
    @When("I enter Invalid destination URL")
    public void enterInvaliddestinationURL(){
        ViewListUserNeg.enterInvaliddestinationURL();
    }
    @And("I click send GET HTTP button")
    public void clicksendGETHTTPbutton(){
        ViewListUserNeg.clicksendGETHTTPbutton();
    }
    @Then("I receive GET valid HTTP response code 404 Not Found")
    public void receiveGETvalidHTTPresponsecode404NotFound(){
        ViewListUserNeg.receiveGETvalidHTTPresponsecode404NotFound();
    }
}
