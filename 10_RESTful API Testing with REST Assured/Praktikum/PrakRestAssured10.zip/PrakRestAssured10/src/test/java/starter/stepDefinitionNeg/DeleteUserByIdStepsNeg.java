package starter.stepDefinitionNeg;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.DeleteUserByIdNeg.DeleteUserByIdNeg;

public class DeleteUserByIdStepsNeg {
    @Steps
    DeleteUserByIdNeg deleteUserByIdNeg;

    @Given("I set DELETE method endpoint")
    public void setDELETEmethodendpoint() {
        deleteUserByIdNeg.setDELETEmethodendpoint();
    }

    @When("I enter DELETE destination URL with invalid Id in parameter")
    public void enterDELETEdestinationURLwithInvalidIdinparameter() {
        deleteUserByIdNeg.enterDELETEdestinationURLwithInvalidIdinparameter();
//        // Modify this step to intentionally fail
//        throw new RuntimeException("Intentional test failure!");
    }

    @And("I click send DELETE HTTP button")
    public void clicksendDELETEHTTPbutton() {
        deleteUserByIdNeg.clicksendDELETEHTTPbutton();
    }

    @Then("I should receive DELETE valid HTTP response code 404 Not Found")
    public void shouldreceiveDELETEvalidHTTPresponsecode404NotFound() {
        deleteUserByIdNeg.shouldreceiveDELETEvalidHTTPresponsecode404NotFound();
    }
}
