package starter.stepDefinitionNeg;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.EditUserByIdNeg.EditUserByIdNeg;

public class EditUserByIdStepsNeg {
    @Steps
    EditUserByIdNeg EditUserByIdNeg;

    @Given("I set PUT method endpoint")
    public void setPOSTmethodendpoint(){
        EditUserByIdNeg.setPOSTmethodendpoint();
    }
    @When("I navigate to body menu")
    public void navigatetobodymenu(){
        EditUserByIdNeg.navigatetobodymenu();
    }
    @And("I enter PUT destination URL with Invalid Id in parameter")
    public void enterPUTdestinationURLwithInvalidIdinparameter(){
        EditUserByIdNeg.enterPUTdestinationURLwithInvalidIdinparameter();
    }
    @And("I enter new changes for data user in the body field")
    public void enternewchangesfordatauserinthebodyfield(){
        EditUserByIdNeg.enternewchangesfordatauserinthebodyfield();
    }
    @And("I select option \"raw\"")
    public void selectoptionraw(){
        EditUserByIdNeg.selectoptionraw();
    }
    @And("I select \"JSON\" format from the dropdown")
    public void selectJSONformatfromthedropdown(){
        EditUserByIdNeg.selectJSONformatfromthedropdown();
    }
    @And("I click send PUT HTTP button")
    public void clicksendPUTHTTPbutton(){
        EditUserByIdNeg.clicksendPUTHTTPbutton();
    }
    @Then("I receive PUT valid HTTP response code 404 Not Found")
    public void receivePUTvalidHTTPresponsecode404NotFound(){
        EditUserByIdNeg.receivePUTvalidHTTPresponsecode404NotFound();
    }
}
