//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.ViewListUserNeg;

import net.thucydides.core.annotations.Step;
import org.junit.Assert;

public class ViewListUserNeg {
    @Step("I set method endpoint GET")
    public void setmethodendpointGET(){
    System.out.println("I set method endpoint GET");
}

    @Step("I enter Invalid destination URL")
    public void enterInvaliddestinationURL(){
        System.out.println("I enter Invalid destination URL");
    }

    @Step("I click send GET HTTP button")
    public void clicksendGETHTTPbutton(){
        System.out.println("I click send GET HTTP button");
    }

    @Step("I receive GET valid HTTP response code 404 Not Found")
    public void receiveGETvalidHTTPresponsecode404NotFound(){
        Assert.fail("Expected HTTP response code 404 Not Found but received a 200 OK.");
    }
}
