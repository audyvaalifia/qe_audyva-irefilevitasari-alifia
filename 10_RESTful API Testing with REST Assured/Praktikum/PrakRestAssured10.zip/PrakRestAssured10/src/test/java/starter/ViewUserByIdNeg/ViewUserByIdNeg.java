//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.ViewUserByIdNeg;

import net.thucydides.core.annotations.Step;
import org.junit.Assert;

public class ViewUserByIdNeg {

    @Step("I set method endpoints GET")
    public void setmethodendpointsGET() {
        System.out.println("I set method endpoints GET");
    }

    @Step("I enter Invalid GET destination URL with Id in parameter")
    public void enterInvalidGETdestinationURLwithIdinparameter() {
        System.out.println("I enter Invalid GET destination URL with Id in parameter");
    }

    @Step("I click Send GET HTTP button")
    public void clickSendGETHTTPbutton() {
        System.out.println("I click Send GET HTTP button");
    }

    @Step("I receive valid HTTP response code 404 Not Found")
    public void receivevalidHTTPresponsecode404NotFound() {
        Assert.fail("Expected HTTP response code 404 Not Found but received a 200 OK.");
    }

}
