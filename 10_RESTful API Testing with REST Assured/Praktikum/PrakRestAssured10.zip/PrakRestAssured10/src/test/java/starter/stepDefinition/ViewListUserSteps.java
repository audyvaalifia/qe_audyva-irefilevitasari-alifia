package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.ViewListUser.ViewListUser;

public class ViewListUserSteps {
    @Steps
    ViewListUser ViewListUser;
    @Given("I set GET method endpoints")
    public void setGETmethodendpoints(){
        ViewListUser.setGETmethodendpoints();
    }
    @When("I enter destination URL")
    public void enterGETdestinationURL(){
        ViewListUser.enterGETdestinationURL();
    }
    @And("I click send GET HTTP request button")
    public void clicksendGETHTTPrequestbutton(){
        ViewListUser.clicksendGETHTTPrequestbutton();
    }
    @Then("I receive valid HTTP response code 200")
    public void receivevalidHTTPresponsecode200(){
        ViewListUser.receivevalidHTTPresponsecode200();
    }
    @And("I receive the list of data posts")
    public void receivethelistofdataposts(){
        ViewListUser.receivethelistofdataposts();
    }
}
