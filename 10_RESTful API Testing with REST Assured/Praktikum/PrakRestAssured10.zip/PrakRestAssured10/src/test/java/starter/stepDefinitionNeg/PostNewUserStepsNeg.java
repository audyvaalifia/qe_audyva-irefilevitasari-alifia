package starter.stepDefinitionNeg;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.PostNewUserNeg.PostNewUserNeg;

public class PostNewUserStepsNeg {
    @Steps
    PostNewUserNeg PostNewUserNeg;

    @Given("I set POST method endpoint")
    public void setPOSTmethodendpoint(){
        PostNewUserNeg.setPOSTmethodendpoint();
    }
    @When("I navigate to menu named Body")
    public void navigatetomenunamedBody(){
        PostNewUserNeg.navigatetomenunamedBody();
    }
    @And("I enter destination POST URL")
    public void enterdestinationPOSTURL(){
        PostNewUserNeg.enterdestinationPOSTURL();
    }
    @And("I enter an Invalid new data user in body field")
    public void enteranInvalidnewdatauserinbodyfield(){
        PostNewUserNeg.enteranInvalidnewdatauserinbodyfield();
    }
    @And("I select option named \"raw\"")
    public void selectoptionnamedraw(){
        PostNewUserNeg.selectoptionnamedraw();
    }
    @And("I select \"JSON\" format from dropdown")
    public void selectJSONformatfromdropdown(){
        PostNewUserNeg.selectJSONformatfromdropdown();
    }
    @And("I click send POST HTTP button")
    public void clicksendPOSTHTTPbutton(){
        PostNewUserNeg.clicksendPOSTHTTPbutton();
    }
    @Then("I receive POST valid HTTP response code 404 Not Found")
    public void receivePOSTvalidHTTPresponsecode404NotFound(){
        PostNewUserNeg.receivePOSTvalidHTTPresponsecode404NotFound();
    }
}
