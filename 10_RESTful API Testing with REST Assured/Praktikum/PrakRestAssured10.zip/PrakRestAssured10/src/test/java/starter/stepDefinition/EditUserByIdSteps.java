package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.EditUserById.EditUserById;

public class EditUserByIdSteps {
    @Steps
    EditUserById EditUserById;

    @Given("I set PUT method endpoints")
    public void setPOSTmethodendpoints(){
        EditUserById.setPOSTmethodendpoints();
    }
    @When("I navigate to the Body menu")
    public void navigatetoBodymenu(){
        EditUserById.navigatetoBodymenu();
    }
    @And("I enter PUT destination URL with Id in parameter")
    public void enterPUTdestinationURLwithId(){
        EditUserById.enterPUTdestinationURLwithId();
    }
    @And("I enter new changes for data user in body field")
    public void enternewdatauserinbodyfield(){
        EditUserById.enternewdatauserinbodyfield();
    }
    @And("I select \"raw\" option")
    public void selectraw(){
        EditUserById.selectraw();
    }
    @And("I select \"JSON\" from the text format dropdown")
    public void selectJSON(){
        EditUserById.selectJSON();
    }
    @And("I click send PUT HTTP request button")
    public void clicksendPOSTHTTPrequestbutton(){
        EditUserById.clicksendPOSTHTTPrequestbutton();
    }
    @Then("I receive PUT valid HTTP response code 200")
    public void receivevalidHTTPresponsecode201(){
        EditUserById.receivevalidHTTPresponsecode201();
    }
    @And("I receive the data changes that had been updated to the system")
    public void receivethenewdatathathadbeenadded(){
        EditUserById.receivethenewdatathathadbeenadded();
    }
}
