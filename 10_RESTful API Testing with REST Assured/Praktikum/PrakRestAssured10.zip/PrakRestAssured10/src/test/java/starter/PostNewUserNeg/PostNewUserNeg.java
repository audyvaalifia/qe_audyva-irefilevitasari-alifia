//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.PostNewUserNeg;

import net.thucydides.core.annotations.Step;
import org.junit.Assert;

public class PostNewUserNeg {

    @Step("I set POST method endpoint")
    public void setPOSTmethodendpoint(){
        System.out.println("I set POST method endpoint");
    }

    @Step("I navigate to menu named Body")
    public void navigatetomenunamedBody(){
        System.out.println("I navigate to menu named Body");
    }

    @Step("I enter destination POST URL")
    public void enterdestinationPOSTURL(){
        System.out.println("I enter destination POST URL");
    }

    @Step("I enter an Invalid new data user in body field")
    public void enteranInvalidnewdatauserinbodyfield(){
        System.out.println("I enter an Invalid new data user in body field");
    }

    @Step("I select option named \"raw\"")
    public void selectoptionnamedraw(){
        System.out.println("I select option named \"raw\"");
    }

    @Step("I select \"JSON\" format from dropdown")
    public void selectJSONformatfromdropdown(){
        System.out.println("I select \"JSON\" format from dropdown");
    }

    @Step("I click send POST HTTP button")
    public void clicksendPOSTHTTPbutton(){
        System.out.println("I click send POST HTTP button");
    }

    @Step("I receive POST valid HTTP response code 404 Not Found")
    public void receivePOSTvalidHTTPresponsecode404NotFound(){
        Assert.fail("Expected HTTP response code 201 but received a 404 Not Found.");    }
}
