package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.DeleteUserById.DeleteUserById;

public class DeleteUserByIdSteps {
    @Steps
    DeleteUserById DeleteUserById;

    @Given("I set DELETE method endpoints")
    public void setDELETEmethodendpoints(){
        DeleteUserById.setDELETEmethodendpoints();
    }
    @When("I enter DELETE destination URL with Id in parameter")
    public void enterDELETEdestinationURLwithIdinparameter(){
        DeleteUserById.enterDELETEdestinationURLwithIdinparameter();
    }
    @And("I click send DELETE HTTP request button")
    public void clicksendDELETEHTTPrequestbutton(){
        DeleteUserById.clicksendDELETEHTTPrequestbutton();
    }
    @Then("I receive DELETE valid HTTP response code 204 No Content")
    public void receiveDELETEvalidHTTPresponsecode204NoContent(){
        DeleteUserById.receiveDELETEvalidHTTPresponsecode204NoContent();
    }
}
