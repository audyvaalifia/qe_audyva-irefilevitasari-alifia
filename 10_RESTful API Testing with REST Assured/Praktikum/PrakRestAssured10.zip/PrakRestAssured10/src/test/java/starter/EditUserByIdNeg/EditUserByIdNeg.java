//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.EditUserByIdNeg;

import net.thucydides.core.annotations.Step;
import org.junit.Assert;

public class EditUserByIdNeg {

    @Step("I set PUT method endpoint")
    public void setPOSTmethodendpoint(){
        System.out.println("I set PUT method endpoint");
    }

    @Step("I navigate to body menu")
    public void navigatetobodymenu(){
        System.out.println("I navigate to body menu");
    }

    @Step("I enter PUT destination URL with Invalid Id in parameter")
    public void enterPUTdestinationURLwithInvalidIdinparameter(){
        System.out.println("I enter PUT destination URL with Invalid Id in parameter");
    }

    @Step("I enter new changes for data user in the body field")
    public void enternewchangesfordatauserinthebodyfield(){
        System.out.println("I enter new changes for data user in the body field");
    }

    @Step("I select option \"raw\"")
    public void selectoptionraw(){
        System.out.println("I select option \"raw\"");
    }

    @Step("I select \"JSON\" format from the dropdown")
    public void selectJSONformatfromthedropdown(){
        System.out.println("I select \"JSON\" format from the dropdown");
    }

    @Step("I click send PUT HTTP button")
    public void clicksendPUTHTTPbutton(){
        System.out.println("I click send PUT HTTP button");
    }

    @Step("I receive PUT valid HTTP response code 404 Not Found")
    public void receivePUTvalidHTTPresponsecode404NotFound(){
        Assert.fail("Expected HTTP response code 200 but received a 404 Not Found.");    }


}
