//PUNYA AUDYVA IREFILEVITASARI ALIFIA
package starter.DeleteUserByIdNeg;

import net.thucydides.core.annotations.Step;
import org.junit.Assert;

public class DeleteUserByIdNeg {

    @Step("I set DELETE method endpoint")
    public void setDELETEmethodendpoint() {
        System.out.println("I set DELETE method endpoint");
    }

    @Step("I enter DELETE destination URL with invalid Id in parameter")
    public void enterDELETEdestinationURLwithInvalidIdinparameter() {
        System.out.println("I enter DELETE destination URL with invalid Id in parameter");
    }

    @Step("I click send DELETE HTTP button")
    public void clicksendDELETEHTTPbutton() {
        System.out.println("I click send DELETE HTTP button");
    }

    @Step("I should receive DELETE valid HTTP response code 404 Not Found")
    public void shouldreceiveDELETEvalidHTTPresponsecode404NotFound() {
        Assert.fail("Expected HTTP response code 404 Not Found but received a 200 OK.");    }

}
