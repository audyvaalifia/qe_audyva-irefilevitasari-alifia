import {Given , When, And, Then} from "cypress-cucumber-preprocessor/steps";

Given("I am on the payment page", () =>{
    console.log("I am on the payment page")
    cy.visit("https://www.sepulsa.com/transaction/checkout")
})
When("I enter my email and phone correctly", () =>{
    console.log("I enter my email and phone correctly")
    cy.get('#phone_number').type('081232111390')
    cy.get('#user.email').type('audyvairefilevitasarialifia9@gmail.com')
})
And("I click gopay icon", () =>{
    console.log("I click gopay icon")
    cy.get('#gopay').click()
})
Then("I am on the gopay payment code page", () =>{
    console.log("I am on the gopay payment code page")
    cy.title().should('eql', 'Gopay')
})