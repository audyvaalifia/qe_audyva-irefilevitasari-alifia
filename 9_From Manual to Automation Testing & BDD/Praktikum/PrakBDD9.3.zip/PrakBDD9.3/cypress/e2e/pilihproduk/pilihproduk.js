import {Given , When, And, Then} from "cypress-cucumber-preprocessor/steps";

Given("I am on the Sepulsa home page", () =>{
    console.log("I am on the Sepulsa home page")
    cy.visit("https://www.sepulsa.com/")
})
When("I choose phone credit product", () =>{
    console.log("I choose phone credit product")
})
And("I click pulsa icon", () =>{
    console.log("I click pulsa icon")
    cy.get('#Pulsa').click()
})
Then("I am on the phone credit page", () =>{
    console.log("I am on the phone credit page")
    cy.title().should('eql', 'Jual Isi Pulsa Online Murah, 30 Detik Transaksi Sukses')
})