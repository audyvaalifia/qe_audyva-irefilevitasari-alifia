import {Given , When, And, Then} from "cypress-cucumber-preprocessor/steps";

Given("I am on the login page", () =>{
    console.log("I am on the login page")
    cy.visit("https://www.sepulsa.com/signin/")
})
When("I enter my username and password correctly", () =>{
    console.log("I enter my username and password correctly")
    cy.get('#email').type('audyvairefilevitasarialifia9@gmail.com')
    cy.get('#password').type('dyvaazarath')
})
And("I click login button", () =>{
    console.log("I click login button")
    cy.get('#login').click()
})
Then("I am on the home page", () =>{
    console.log("I am on the home page")
    cy.title().should('eql', 'Sepulsa Mobile | Isi Ulang Pulsa Secara Online Cepat dan Terpercaya')
})