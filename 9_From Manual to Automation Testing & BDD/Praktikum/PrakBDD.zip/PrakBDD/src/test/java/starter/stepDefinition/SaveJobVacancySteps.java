package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.SaveJobVacancy.SaveJobVacancy;

public class SaveJobVacancySteps {
    @Steps
    SaveJobVacancy SaveJobVacancy;

    @Given("I am on the job vacancy page")
    public void onTheJobVacancyPage(){
        SaveJobVacancy.onTheJobVacancyPage();
    }
    @When("I choose job vacancy")
    public void chooseJobVacancy(){
        SaveJobVacancy.chooseJobVacancy();
    }
    @And("I click save job button")
    public void clickSaveJobButton(){
        SaveJobVacancy.clickSaveJobButton();
    }
    @Then("I am able to see saved vacancy in my item menu")
    public void SavedVacancyVisible(){
        SaveJobVacancy.SavedVacancyVisible();
    }
}
