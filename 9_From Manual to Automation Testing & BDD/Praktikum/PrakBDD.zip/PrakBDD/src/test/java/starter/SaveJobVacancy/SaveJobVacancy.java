package starter.SaveJobVacancy;

import net.thucydides.core.annotations.Step;

public class SaveJobVacancy {

    @Step("I am on the job vacancy page")
    public void onTheJobVacancyPage(){
        System.out.println("I am on the job vacancy page");
    }

    @Step("I choose job vacancy")
    public void chooseJobVacancy(){
        System.out.println("I choose job vacancy");
    }

    @Step("I click save job button")
    public void clickSaveJobButton(){
        System.out.println("I click save job button");
    }

    @Step("I am able to see saved vacancy in my item menu")
    public void SavedVacancyVisible(){
        System.out.println("I am able to see saved vacancy in my item menu");
    }
}
