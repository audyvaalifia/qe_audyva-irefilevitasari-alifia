package starter.AddProfileAbout;

import net.thucydides.core.annotations.Step;

public class AddProfileAbout {

    @Step("I am on the profile page")
    public void onTheProfilePage(){
        System.out.println("I am on the profile page");
    }

    @Step("I enter my description about myself")
    public void enterMyDescriptionAboutMyself(){
        System.out.println("I enter my description about myself");
    }

    @Step("I click save button")
    public void clickSaveButton(){
        System.out.println("I click save button");
    }

    @Step("I am able to see my about description in profile page")
    public void onDescriptionProfilePage(){
        System.out.println("I am able to see my about description in profile page");
    }
}
