package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.AddAbilitytoPostCommunity.AddAbilitytoPostCommunity;

public class AddAbilitytoPostCommunitySteps {
    @Steps
    AddAbilitytoPostCommunity AddAbilitytoPostCommunity;

    @Given("I am on the home page")
    public void onTheHomePage(){
        AddAbilitytoPostCommunity.onTheHomePage();
    }
    @When("I choose community")
    public void chooseCommunity(){
        AddAbilitytoPostCommunity.chooseCommunity();
    }
    @And("I click join button")
    public void clickJoinButton(){
        AddAbilitytoPostCommunity.clickJoinButton();
    }
    @Then("I am able to see post feature in community")
    public void postFeatureVisible(){
        AddAbilitytoPostCommunity.postFeatureVisible();
    }
}
