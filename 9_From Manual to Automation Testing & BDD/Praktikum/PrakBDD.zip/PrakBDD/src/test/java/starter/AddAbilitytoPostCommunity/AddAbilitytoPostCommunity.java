package starter.AddAbilitytoPostCommunity;

import net.thucydides.core.annotations.Step;

public class AddAbilitytoPostCommunity {

    @Step("I am on the home page")
    public void onTheHomePage(){
        System.out.println("I am on the home page");
    }

    @Step("I choose community")
    public void chooseCommunity(){
        System.out.println("I choose community");
    }

    @Step("I click join button")
    public void clickJoinButton(){
        System.out.println("I click join button");
    }

    @Step("I am able to see post feature in community")
    public void postFeatureVisible(){
        System.out.println("I am able to see post feature in community");
    }
}
