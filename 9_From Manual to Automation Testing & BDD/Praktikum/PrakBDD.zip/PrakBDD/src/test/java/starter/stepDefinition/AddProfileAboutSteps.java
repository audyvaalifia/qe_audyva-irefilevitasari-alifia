package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.AddProfileAbout.AddProfileAbout;

public class AddProfileAboutSteps {
    @Steps
    AddProfileAbout AddProfileAbout;

    @Given("I am on the profile page")
    public void onTheProfilePage(){
        AddProfileAbout.onTheProfilePage();
    }
    @When("I enter my description about myself")
    public void enterMyDescriptionAboutMyself(){
        AddProfileAbout.enterMyDescriptionAboutMyself();
    }
    @And("I click save button")
    public void clickSaveButton(){
        AddProfileAbout.clickSaveButton();
    }
    @Then("I am able to see my about description in profile page")
    public void onDescriptionProfilePage(){
        AddProfileAbout.onDescriptionProfilePage();
    }
}
