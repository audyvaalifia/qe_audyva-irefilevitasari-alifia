package starter.Login;

import net.thucydides.core.annotations.Step;

public class Login {

    @Step("I am on the login page")
    public void onTheLoginPage(){
        System.out.println("I am on the login page");
    }

    @Step("I enter my email or phone and password correctly")
    public void enterEmailOrPhoneAndPassword(){
        System.out.println("I enter my email or phone and password correctly");
    }

    @Step("I click masuk button")
    public void clickMasukButton(){
        System.out.println("I click masuk button");
    }

    @Step("I am on the Sepulsa home page")
    public void onTheSepulsaHomePage(){
        System.out.println("I am on the Sepulsa home page");
    }
}
