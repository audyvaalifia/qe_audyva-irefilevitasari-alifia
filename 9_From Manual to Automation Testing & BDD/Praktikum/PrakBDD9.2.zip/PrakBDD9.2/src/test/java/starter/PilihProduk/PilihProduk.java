package starter.PilihProduk;

import net.thucydides.core.annotations.Step;

public class PilihProduk {

    @Step("I am on the home page")
    public void onTheHomePage(){
        System.out.println("I am on the home page");
    }

    @Step("I choose phone credit product")
    public void choosePhoneCreditProduct(){
        System.out.println("I choose phone credit product");
    }

    @Step("I click pulsa icon")
    public void clickPulsaIcon(){
        System.out.println("I click pulsa icon");
    }

    @Step("I am on the phone credit page")
    public void onThePhoneCreditPage(){
        System.out.println("I am on the phone credit page");
    }
}
