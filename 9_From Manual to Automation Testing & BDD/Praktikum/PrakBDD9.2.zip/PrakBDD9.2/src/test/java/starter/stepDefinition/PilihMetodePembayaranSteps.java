package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.PilihMetodePembayaran.PilihMetodePembayaran;

public class PilihMetodePembayaranSteps {
    @Steps
    PilihMetodePembayaran PilihMetodePembayaran;

    @Given("I am on the payment page")
    public void onThePaymentPage(){
        PilihMetodePembayaran.onThePaymentPage();
    }
    @When("I enter my email and phone correctly")
    public void enterEmailAndPasswordCorrectly(){
        PilihMetodePembayaran.enterEmailAndPasswordCorrectly();
    }
    @And("I click gopay icon")
    public void clickGopayIcon(){
        PilihMetodePembayaran.clickGopayIcon();
    }
    @Then("I am on the gopay payment code page")
    public void onTheGopayPaymentCodePage(){
        PilihMetodePembayaran.onTheGopayPaymentCodePage();
    }
}
