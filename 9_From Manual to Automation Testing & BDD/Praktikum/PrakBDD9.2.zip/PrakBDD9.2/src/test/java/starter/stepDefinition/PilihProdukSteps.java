package starter.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.PilihProduk.PilihProduk;

public class PilihProdukSteps {
    @Steps
    PilihProduk PilihProduk;

    @Given("I am on the home page")
    public void onTheHomePage(){
        PilihProduk.onTheHomePage();
    }
    @When("I choose phone credit product")
    public void choosePhoneCreditProduct(){
        PilihProduk.choosePhoneCreditProduct();
    }
    @And("I click pulsa icon")
    public void clickPulsaIcon(){
        PilihProduk.clickPulsaIcon();
    }
    @Then("I am on the phone credit page")
    public void onThePhoneCreditPage(){
        PilihProduk.onThePhoneCreditPage();
    }
}
