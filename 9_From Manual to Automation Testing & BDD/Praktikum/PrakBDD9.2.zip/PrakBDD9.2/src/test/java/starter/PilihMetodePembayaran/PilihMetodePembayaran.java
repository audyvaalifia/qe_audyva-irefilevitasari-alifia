package starter.PilihMetodePembayaran;

import net.thucydides.core.annotations.Step;

public class PilihMetodePembayaran {

    @Step("I am on the payment page")
    public void onThePaymentPage(){
        System.out.println("I am on the payment page");
    }

    @Step("I enter my email and phone correctly")
    public void enterEmailAndPasswordCorrectly(){
        System.out.println("I enter my email and phone correctly");
    }

    @Step("I click gopay icon")
    public void clickGopayIcon(){
        System.out.println("I click gopay icon");
    }

    @Step("I am on the gopay payment code page")
    public void onTheGopayPaymentCodePage(){
        System.out.println("I am on the gopay payment code page");
    }
}
